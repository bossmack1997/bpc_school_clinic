/* Native details/summary works without JavaScript; keep older browsers exclusive too. */
(function () {
  'use strict';
  var menu = document.getElementById('settingsMenu');
  if (!menu) return;
  var sections = Array.from(menu.querySelectorAll('details.settings-menu__item'));
  sections.forEach(function (section) {
    section.addEventListener('toggle', function () {
      if (!section.open) return;
      sections.forEach(function (other) { if (other !== section) other.open = false; });
    });
  });
  menu.addEventListener('invalid', function (event) {
    var section = event.target.closest('details.settings-menu__item');
    if (section) section.open = true;
  }, true);
})();
