<?php
require_once __DIR__ . '/../../config/config.php';
require_role('admin');
// Preserve existing search/page links while opening the integrated log viewer.
$params = ['tab' => 'activity-logs'];
foreach (['search', 'page'] as $key) {
    if (isset($_GET[$key]) && is_scalar($_GET[$key])) $params[$key] = (string)$_GET[$key];
}
redirect('settings.php?' . http_build_query($params));
