<?php
/** Legacy Security URL: preserve bookmarks and submissions from already-open forms. */
require_once __DIR__ . '/../../config/config.php';
require_admin_permission('manage_security');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('settings.php?tab=security');
    exit;
}

// Dispatch old POSTs through the same CSRF-protected Settings handlers.
$_GET['tab'] = 'security';
require __DIR__ . '/settings.php';
