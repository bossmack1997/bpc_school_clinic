<?php
/** Deterministic inventory facts shared by MICA, scheduled checks and requisitions. */
final class MedicineInventoryService
{
    public function __construct(private PDO $db) {}

    public static function classify(array $m, string $today): array
    {
        $expired = !empty($m['expiration_date']) && $m['expiration_date'] < $today;
        $unusable = $expired || !empty($m['is_quarantined'])
            || (isset($m['is_available']) && !$m['is_available'])
            || in_array(strtolower((string)($m['status'] ?? '')), ['quarantined','unusable','recalled'], true);
        $m['usable_stock'] = $unusable ? 0 : max(0, (int)$m['quantity']);
        $threshold = isset($m['reorder_level']) && is_numeric($m['reorder_level']) && $m['reorder_level'] >= 0
            ? (int)$m['reorder_level'] : null;
        $m['reorder_level'] = $threshold;
        $m['stock_status'] = $m['usable_stock'] === 0 ? 'OUT OF STOCK'
            : ($threshold === null ? 'THRESHOLD REQUIRED' : ($m['usable_stock'] <= $threshold ? 'LOW STOCK' : 'AVAILABLE'));
        $m['remarks'] = $expired ? 'Expired stock excluded' : ($unusable ? 'Unusable stock excluded' : 'Inventory replenishment');
        $target = isset($m['target_stock_level']) && is_numeric($m['target_stock_level']) ? (int)$m['target_stock_level'] : null;
        $m['suggested_quantity'] = $target === null ? null : max(0, $target - $m['usable_stock']);
        return $m;
    }

    public function snapshot(): array
    {
        // Each existing ID is a distinct inventory/batch record. Never merge different IDs by name.
        $rows = $this->db->query("SELECT * FROM medicines WHERE is_archived = 0 ORDER BY medicine_name, id")->fetchAll(PDO::FETCH_ASSOC);
        $today = (string)$this->db->query('SELECT CURDATE()')->fetchColumn();
        $items = [];
        foreach ($rows as $m) $items[(int)$m['id']] = self::classify($m, $today);
        return $items;
    }

    public static function low(array $items): array
    {
        return array_filter($items, fn($m) => in_array($m['stock_status'], ['LOW STOCK','OUT OF STOCK'], true));
    }

    public static function requisitionItems(array $items): array
    {
        return array_filter(self::low($items), fn($m) => $m['reorder_level'] !== null && $m['usable_stock'] <= $m['reorder_level']);
    }

    /** Validate the exact preview revision against fresh inventory before any export. */
    public static function verifiedDraft(array $draft, array $items, int $owner, string $revision): array
    {
        if (($draft['owner'] ?? null) !== $owner || empty($draft['confirmed'])) {
            throw new InvalidArgumentException('Review and confirm the requisition preview before downloading.');
        }
        if ($revision === '' || !hash_equals($draft['revision'] ?? '', $revision)) {
            throw new InvalidArgumentException('This preview has changed. Reopen it and confirm the current draft.');
        }
        $low = self::requisitionItems($items);
        $quantities = self::quantities($draft['quantities'] ?? [], $low);
        $selected = array_intersect_key($low, $quantities);
        if (!hash_equals($draft['confirmed_hash'] ?? '', self::fingerprint($selected))) {
            throw new InvalidArgumentException('Inventory changed. Review the updated stock and confirm the draft again.');
        }
        foreach ($selected as $id => &$item) $item['requested_quantity'] = $quantities[$id];
        unset($item);
        return array_values($selected);
    }

    public static function fingerprint(array $items): string
    {
        $facts = [];
        foreach ($items as $id => $m) $facts[$id] = [$m['medicine_name'], $m['quantity'], $m['usable_stock'], $m['unit'], $m['reorder_level'], $m['expiration_date'] ?? null, $m['stock_status'], $m['batch_number'] ?? null, $m['suggested_quantity']];
        ksort($facts);
        return hash('sha256', json_encode($facts));
    }

    public function monitor(): array
    {
        $lock = $this->db->query("SELECT GET_LOCK('bpc_mica_stock_monitor', 2)")->fetchColumn();
        if ((int)$lock !== 1) return ['notified' => 0];
        try {
            $this->db->beginTransaction();
            $items = $this->snapshot();
            $get = $this->db->prepare('SELECT setting_value FROM system_settings WHERE setting_key = ?');
            $save = $this->db->prepare('INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
            $notify = $this->db->prepare("INSERT INTO notifications (user_id, type, title, message, link) SELECT id, 'mica_inventory', ?, ?, ? FROM users WHERE role IN ('admin','nurse') AND status = 'active'");
            $count = 0;
            foreach ($items as $id => $m) {
                $key = 'mica_stock_state_' . $id;
                $get->execute([$key]);
                $previous = json_decode((string)$get->fetchColumn(), true);
                $state = ['quantity' => $m['usable_stock'], 'status' => $m['stock_status'], 'threshold' => $m['reorder_level']];
                $low = in_array($state['status'], ['LOW STOCK','OUT OF STOCK'], true);
                if ($low && (!$previous || !in_array($previous['status'], ['LOW STOCK','OUT OF STOCK'], true)
                    || $state['quantity'] < $previous['quantity'] || $state['status'] !== $previous['status'] || $state['threshold'] !== ($previous['threshold'] ?? null))) {
                    $message = mb_substr($m['medicine_name'] . ': ' . $m['usable_stock'] . ' ' . $m['unit'] . ' usable. ' . $m['stock_status'] . '. Review in MICA or generate a requisition.', 0, 255);
                    $notify->execute(['Medicine Inventory Alert', $message, APP_URL . '/pages/medicine_requisition.php']);
                    $count++;
                }
                $save->execute([$key, json_encode($state)]);
            }
            $this->db->commit();
            return ['count' => count(self::low($items)), 'notified' => $count, 'reorders_created' => 0];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        } finally {
            $this->db->query("SELECT RELEASE_LOCK('bpc_mica_stock_monitor')");
        }
    }

    public static function quantities(array $posted, array $low): array
    {
        $selected = [];
        foreach ($posted as $id => $value) {
            if (!ctype_digit((string)$id) || !isset($low[(int)$id])) throw new InvalidArgumentException('A selected medicine is no longer low stock. Refresh the draft.');
            if (!is_scalar($value) || !preg_match('/^[1-9][0-9]{0,6}$/D', (string)$value)) throw new InvalidArgumentException('Enter a whole requested quantity from 1 to 9999999 for every selected item.');
            $selected[(int)$id] = (int)$value;
        }
        if (!$selected) throw new InvalidArgumentException('Select at least one low-stock medicine.');
        return $selected;
    }
}
